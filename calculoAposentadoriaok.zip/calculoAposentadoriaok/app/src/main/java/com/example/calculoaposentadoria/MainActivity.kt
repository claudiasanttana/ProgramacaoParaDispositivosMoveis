package com.example.calculoaposentadoria

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val spinSexo = findViewById<Spinner>(R.id.spinSexo)
        val txtIdade = findViewById<EditText>(R.id.txtIdade)
        val btnCalcular = findViewById<Button>(R.id.btn_Calcular)
        val txtResultado = findViewById<TextView>(R.id.txt_Resultado)

        spinSexo.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("Masculino", "Feminino")
        )

        btnCalcular.setOnClickListener {
            val idadeInput = txtIdade.text.toString()

            // Validação para idade vazia
            if (idadeInput.isEmpty()) {
                txtResultado.text = "Por favor, insira a sua idade."
                return@setOnClickListener
            }

            val idade = idadeInput.toIntOrNull()

            // Validação para idade inválida
            if (idade == null || idade < 0) {
                txtResultado.text = "Por favor, insira uma idade válida e maior que 0."
                return@setOnClickListener
            }

            val sexo = spinSexo.selectedItem as String
            val resultado = if (sexo == "Masculino") {
                65 - idade
            } else {
                62 - idade
            }

            // Saída
            txtResultado.text = if (resultado > 0) {
                "Faltam $resultado anos para você se aposentar!"
            } else {
                "Você já pode se aposentar!"
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
